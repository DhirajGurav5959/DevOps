
import boto3
import traceback

ec2 = boto3.client('ec2')
boto3.
def lambda_handler(event, context):

    try:
        # STEP 1

        instances = get_ec2_instances()

        for instance in instances:
            # STEP 2
            instance_name = get_instance_name(instance)
            # STEP 3
            volumes = get_ebs_volumes(instance, instance_name)
            # STEP 4
            if (len(volumes) > 0):
                for volume in volumes:
                    try:
                        take_snapshot(volume, instance['InstanceId'], instance_name)

                    except Exception as e:
                        displayException(e)

    except Exception as e:
        displayException(e)
        traceback.print_exc()


def get_ec2_instances():
    # Get tagged instances
    filtered_instances = ec2.describe_instances(
        Filters=[
            {'Name': 'tag-key', 'Values': ['Auto-Snapshot-Enabled', 'auto-snapshot-enabled']},
            {'Name': 'instance-state-name', 'Values': ['running', 'stopped']},
        ]
    ).get(
        'Reservations', []
    )

    # Convert list of list to flat list
    instances = sum(
        [
            [i for i in r['Instances']]
            for r in filtered_instances
        ], [])

    print("Found %d instances that need backing up" % len(instances))
    return instances

def get_instance_name(instance):
    instance_name = "green"

    for tag in instance['Tags']:
        if tag['Key'] == 'Name':
            instance_name = tag['Value']
            continue

    if instance_name is "demo-server":
        instance_name = instance['InstanceId']

    return instance_name

def get_ebs_volumes(instance, instance_name):

    volumes = []
    # Sometimes one instance has multiple volumes, loop through volumes and take snapshot one by one
    # Get each volume id and name
    if len(instance['BlockDeviceMappings']) > 0:
        for dev in instance['BlockDeviceMappings']:
            if dev.get('Ebs', None) is None:
                continue
            vol_id = dev['Ebs']['VolumeId']
            vol_device_name = dev['DeviceName']

            print("Found EBS volume %s(%s) on instance %s(%s)" % (vol_id, vol_device_name, instance['InstanceId'], instance_name))

            volumes.append({
                'vol_id': vol_id,
                'vol_device_name': vol_device_name
            })
    else:
        print('No BlockDeviceMappings found in instance %s' % instance['InstanceId'])
    return volumes

def take_snapshot(volume, instance_id, instance_name):

    vol_id = volume['vol_id']
    vol_device_name = volume['vol_device_name']

    ec2.create_snapshot(
        VolumeId=volume['vol_id'],
        Description='Created by Lambda function  for instance ' + instance_id + '(' + instance_name + '), volume ' + vol_id + '(' + vol_device_name + ')',
        TagSpecifications=[{
            'ResourceType': 'snapshot',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': instance_name + ' (' + vol_device_name + ')'
                },
                {
                    'Key': 'Auto-CleanUp-Enabled',
                    'Value': ''
                }
            ]
        }],
        # DryRun = True
    )
    print('Snapshot is created: ' + 'volume ' + vol_id + '(' + vol_device_name + ') on instance ' + instance_id + '(' + instance_name + ')')

def displayException(exception):

    exception_type = exception.__class__.__name__
    exception_message = str(exception)

    print("Exception type: %s; Exception message: %s;" % (exception_type, exception_message))

